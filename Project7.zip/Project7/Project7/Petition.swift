//
//  Petition.swift
//  Project7
//
//  Created by Karpinets Alexander on 11.05.2021.
//

import Foundation

struct Petition: Codable {
    var title: String
    var body: String
    var signatureCount: Int
}
