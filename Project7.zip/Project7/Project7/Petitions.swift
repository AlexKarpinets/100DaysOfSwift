//
//  Petitions.swift
//  Project7
//
//  Created by Karpinets Alexander on 11.05.2021.
//

import Foundation

struct Petitions: Codable {
    var results: [Petition]
}
