//
//  ViewController.swift
//  ShoppingList
//
//  Created by Karpinets Alexander on 10.05.2021.
//

import UIKit
var shoppingList = [String]()


class ViewController: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(addProduct))
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Обновить", style: .plain, target: self, action: #selector(updateList))
//        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .action, target: self, action: #selector(Action))
        
        let list = shoppingList.joined(separator: "\n")
        
        updateList()
    }
  
   
    @IBAction func shareTapped(_ sender: UIBarButtonItem) {
    }
    
    
    @objc func updateList() {
   shoppingList.removeAll(keepingCapacity: true)
    tableView.reloadData()
}
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shoppingList.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ShoppingList", for: indexPath)
        cell.textLabel?.text = shoppingList[indexPath.row]
        return cell
    }
    
    @objc func addProduct() {
        let ac = UIAlertController(title: "Введите наименование товара", message: nil, preferredStyle: .alert)
        // добавляет поле ввода текста
        ac.addTextField()

        let submitAction = UIAlertAction(title: "Подтвердить", style: .default) { [weak self, weak ac] action in
            guard let answer = ac?.textFields?[0].text else { return }
            self?.submit(answer)
        }

        ac.addAction(submitAction)
        present(ac, animated: true)
    }
    
    func submit(_ answer: String) {
        shoppingList.insert(answer, at: 0)
        let indexPath = IndexPath(row: 0, section: 0)
        tableView.insertRows(at: [indexPath], with: .automatic)

        return
}
//    @objc func Action() {
//
//        let vc = UIActivityViewController(activityItems: [shoppingList], applicationActivities: [])
//        vc.popoverPresentationController?.barButtonItem = navigationItem.rightBarButtonItem
//        present(vc, animated: true)
//    }
}
